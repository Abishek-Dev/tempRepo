package com.medassist.aiinteraction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedAssistApplicationTests {

	@Test
	void contextLoads() {
	}

}
