package com.medassist.aiinteraction.controller;

import java.io.IOException;
import java.net.ConnectException;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.multipart.MultipartFile;

import com.medassist.aiinteraction.service.MedAssistService;

@RestController
@RequestMapping("/api/medassist")
@CrossOrigin(origins = "http://localhost:4200")
public class MedAssistController {

	@Autowired
	MedAssistService medAssistService;

	@PostMapping("/generatePrescription")
	public ResponseEntity<String> generatePrescription(@RequestHeader("Authorization") String token,
			@RequestParam("file") MultipartFile file) throws ConnectException, Exception, ResourceAccessException {
		String prompt = "";
		try {
			byte[] bytes = file.getBytes();
			prompt = new String(bytes, StandardCharsets.UTF_8);
		} catch (IOException e) {
			return new ResponseEntity<String>("Failed to read file: " + e.getMessage(), HttpStatus.NO_CONTENT);
//            return  new ResponseEntity<String>(sampleService.generatePrescription(prompt), HttpStatus.OK);

		}
//		try {
			return new ResponseEntity<String>(medAssistService.generatePrescription(token, prompt), HttpStatus.OK);
//		} catch (ResourceAccessException e) {
//			return new ResponseEntity<String>("Network Err", HttpStatus.UNAUTHORIZED);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			return new ResponseEntity<String>("Network Err", HttpStatus.UNAUTHORIZED);
//		}
	}
	
    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestHeader("Authorization") String token, @RequestParam("file") MultipartFile file) {
        try {
            String responseData = medAssistService.storeFile(token, file); // Get response data from the service
            return ResponseEntity.ok("File uploaded successfully! Response Data: " + responseData);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("Error uploading file: " + e.getMessage());
        }
    }

}
