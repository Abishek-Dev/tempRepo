package com.medassist.aiinteraction.service;

import jakarta.servlet.http.HttpServletRequest;

import java.io.IOException;
import java.io.InputStream;
import java.net.ConnectException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class MedAssistService {

	@Autowired
	RestTemplate restTemplate;

	@SuppressWarnings("deprecation")
	public String generatePrescription(String authToken, String prompt) throws Exception, ConnectException, ResourceAccessException {
		prompt = prompt + " flagEnd ";
		System.out.println("prompt = " + prompt);
		String x = "";
		String data = "";
		String url = "http://20.163.181.186:5001/chat/?prompt=" + prompt;
		HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization",authToken);
		HttpEntity<String> entity = new HttpEntity<>(headers);
		try {
			ResponseEntity<String> responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
			String response = responseEntity.getBody();
			ObjectMapper objectMapper = new ObjectMapper();

			try {
				JsonNode rootNode = objectMapper.readTree(response);
				JsonNode dataNode = rootNode.get("data");
				if (dataNode != null) {
					data = dataNode.asText();
				}
			} catch (Exception e) {
				return "Exception";
			}
			String[] words = data.split("\\s");
			for (int i = words.length - 1; i >= 0; i--) {
				System.out.println("Backward Iteration Word[i] = " + words[i]);
				if (words[i].equals("flagEnd")) {
					System.out.println("Found the word i = " + i);
					for (int j = i + 1; j < words.length - 1; j++) {
						System.out.println("word formation = " + words[j]);
						if (words[j] != "" && words[j] != "Note:")
							x += words[j] + " ";
						if (words[j] == "Note:") {
							System.out.println("resultant string1 = " + x);
							return x;
						}
					}
					System.out.println("resultant string2 = " + x);
					return x;
				}
			}
			System.out.println("resultant string3 = " + x);
		} catch (ResourceAccessException e) {
			return e.getMessage();
		}

		return x;
	}
	private static final String UPLOAD_DIR = "C:\\Users\\abish\\OneDrive\\Documents\\MedAssist\\MedAssistBackend\\AIInteraction\\src\\main\\resources\\videos";

	public String storeFile(String authToken, MultipartFile file) throws IOException {
		try {
			java.nio.file.Path filePath = Paths.get(UPLOAD_DIR, file.getOriginalFilename());
			System.out.println("file name = " + file.getOriginalFilename());
			Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
			String scriptPath = "pscp -i C:\\Users\\abish\\vm-10.ppk C:\\Progra~1\\PuTTY\\" + file.getOriginalFilename()
					+ " azureuser@20.163.181.186:/home/azureuser/hf/nlp/api/files";
			System.out.println("Script path = " + scriptPath);
			Process process = Runtime.getRuntime().exec(scriptPath);
			System.out.println("Process sw = " + process);
			String url = "http://20.163.181.186:5001/nlp/?filepath=" + file.getOriginalFilename();
			process.waitFor();
			String prompt = restTemplateFunction(url, HttpMethod.GET, authToken);
			return prompt;
		} catch (Exception e) {
			System.out.println("Exception error :" + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	private String restTemplateFunction(String url, HttpMethod httpMethod, String authToken) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", authToken);
		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String> responseEntity = restTemplate.exchange(url, httpMethod, entity, String.class);
		String response = responseEntity.getBody();
		ObjectMapper objectMapper = new ObjectMapper();
		String data = "";

		try {
			JsonNode rootNode = objectMapper.readTree(response);
			JsonNode dataNode = rootNode.get("data");
			if (dataNode != null) {
				data = dataNode.asText();
			}
		} catch (Exception e) {
			return "Exception";
		}
		return data;
		// TODO Auto-generated method stub
	}
	
//	public String generatePrescription(String prompt, String authToken) {
//		prompt = prompt + " flagEnd ";
//		String url = "http://20.163.181.186:5001/chat/?prompt=" + prompt;
//		String aiResponse = restTemplateFunction(url, HttpMethod.GET, authToken);
//		String[] words = aiResponse.split("\\s");
//		String x = "";
//		for (int i = words.length - 1; i >= 0; i--) {
//			System.out.println("Backward Iteration Word[i] = " + words[i]);
//			if (words[i].equals("flagEnd")) {
//				System.out.println("Found the word i = " + i);
//				for (int j = i + 1; j < words.length - 1; j++) {
//					System.out.println("word formation = " + words[j]);
//					if (words[j] != "" && words[j] != "Note:")
//						x += words[j] + " ";
//					if (words[j] == "Note:") {
//						System.out.println("resultant string1 = " + x);
//						return x;
//					}
//				}
//				System.out.println("resultant string2 = " + x);
//				return x;
//			}
//		}
//		return x;
//	}

}